using System.Threading.Tasks;
using TipsyBaboonTestSite.Services;
using TipsyBaboonTestSite.Services.Identity;
using TipsyBaboon.Core.Startup;
using TipsyBaboon.SqlServer.Extensions;
using TipsyBaboon.UI.Extensions;
using TipsyBaboon.UI.Middleware;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using TipsyBaboon.Core.Models.Governance;
using IdentityUser = TipsyBaboonTestSite.Services.Identity.Models.IdentityUser;
using IdentityRole = TipsyBaboonTestSite.Services.Identity.Models.IdentityRole;

namespace TipsyBaboonTestSite
{
    public class Program
    {
        public static readonly Guid MatthewUserId = Guid.Parse("83B36BD5-B123-4109-80F2-8153768296FF");
        public static readonly Guid VeritoUserId = Guid.Parse("9A73E943-AD98-4611-B103-E920EA98FC78");

        public static async Task Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            var connStr = builder.Configuration.GetConnectionString("TipsyBaboonCore") 
                ?? throw new InvalidOperationException("Connection string 'TipsyBaboonCore' not configured");

            builder.Services.AddTipsyBaboon(config =>
            {
                config.UseSqlServer();
                config.AddModule("TipsyBaboon.Core", connStr, "Core framework module");
                
                config.AddModule("Governance", connStr, "Governance module (permissions, roles, etc.)")
                      // Seed test users for development
                      .AddSeed(new User
                      {
                          Id = MatthewUserId,
                          UserName = "matthewrkuhn@gmail.com",
                          NormalizedUserName = "MATTHEWRKUHN@GMAIL.COM",
                          Email = "matthewrkuhn@gmail.com",
                          NormalizedEmail = "MATTHEWRKUHN@GMAIL.COM",
                          EmailConfirmed = true,
                          SecurityStamp = "E5JTCANNVTVCHRZQNFH2HANESE742RER",
                          TwoFactorEnabled = false,
                          LockoutEnabled = true,
                          AccessFailedCount = 0,
                          IsActive = true,
                          DisplayName = "Matthew Kuhn",
                          CreatedByDisplayName = "System",
                          OwnershipLevel = TipsyBaboon.Core.OwnershipLevel.Public
                      })
                      .AddSeed(new User
                      {
                          Id = VeritoUserId,
                          UserName = "veritoanimus82@gmail.com",
                          NormalizedUserName = "VERITOANIMUS82@GMAIL.COM",
                          Email = "veritoanimus82@gmail.com",
                          NormalizedEmail = "VERITOANIMUS82@GMAIL.COM",
                          EmailConfirmed = true,
                          SecurityStamp = "M7UYUHRZ6IZ7O4BML3EKXPBEQXFKMWNN",
                          TwoFactorEnabled = false,
                          LockoutEnabled = true,
                          AccessFailedCount = 0,
                          IsActive = true,
                          DisplayName = "Matthew Kuhn",
                          CreatedByDisplayName = "System",
                          OwnershipLevel = TipsyBaboon.Core.OwnershipLevel.Public
                      })
                      .AddSeed(new UserLogin
                      {
                          Id = Guid.NewGuid(),
                          UserId = MatthewUserId,
                          LoginProvider = "Google",
                          ProviderKey = "109935667042641713964",
                          ProviderDisplayName = "Google",
                          CreatedByDisplayName = "System",
                          OwnershipLevel = TipsyBaboon.Core.OwnershipLevel.Public
                      })
                      .AddSeed(new UserLogin
                      {
                          Id = Guid.NewGuid(),
                          UserId = VeritoUserId,
                          LoginProvider = "Google",
                          ProviderKey = "114465072791508297323",
                          ProviderDisplayName = "Google",
                          CreatedByDisplayName = "System",
                          OwnershipLevel = TipsyBaboon.Core.OwnershipLevel.Public
                      })
                      .AddSeed(new UserRole
                      {
                          UserId = MatthewUserId,
                          RoleId = Role.UserAdminRoleId,
                          CreatedByDisplayName = "System",
                          OwnershipLevel = TipsyBaboon.Core.OwnershipLevel.Public
                      });
                
                config.AddModule("Identity", connStr, "Identity module (users, roles)");
                
                config.AddModule("TipsyBaboon.UI", connStr, "UI framework module (grid settings, layout preferences)");
                
                // Fishing Log module with seed data
                var fishingModule = config.AddModule("Northwind", connStr, "Northwind Test Environment");
                
                
            });

            builder.Services.AddTipsyBaboonUI();
            
            builder.Services.AddTipsyBaboonGenericPages(routePrefix: "Tipsy");
            builder.Services.AddTipsyBaboonGenericApis(routePrefix: "api/Baboon");

            // Entity Framework DbContext for Identity
            builder.Services.AddDbContext<GovernanceDbContext>(options =>
                options.UseSqlServer(connStr));

            // Northwind test DbContext (scaffolded from local Northwind DB)
            builder.Services.AddDbContext<Models.Northwind.NorthwindContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("Northwind")));

            // Microsoft Identity with custom stores (uses existing TipsyBaboon tables)
            builder.Services.AddIdentityCore<IdentityUser>(options =>
            {
                options.Password.RequireDigit = true;
                options.Password.RequireLowercase = true;
                options.Password.RequireUppercase = true;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequiredLength = 8;
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
                options.Lockout.MaxFailedAccessAttempts = 5;
                options.Lockout.AllowedForNewUsers = true;
                options.User.RequireUniqueEmail = true;
            })
            .AddRoles<IdentityRole>()
            .AddUserStore<TipsyBaboonUserStore>()
            .AddRoleStore<TipsyBaboonRoleStore>()
            .AddSignInManager()
            .AddDefaultTokenProviders();

            // Authentication configuration - using credentials from appsettings.json
            var googleClientId = builder.Configuration["Authentication:Google:ClientId"];
            var googleSecret = builder.Configuration["Authentication:Google:ClientSecret"];
            var microsoftClientId = builder.Configuration["Authentication:Microsoft:ClientId"];
            var microsoftSecret = builder.Configuration["Authentication:Microsoft:ClientSecret"];

            builder.Services.AddTipsyBaboonAuthentication(auth =>
            {
                auth.UseCookieAuth();

                if (!string.IsNullOrEmpty(googleClientId) && !string.IsNullOrEmpty(googleSecret))
                {
                    auth.AddGoogle(options =>
                    {
                        options.ClientId = googleClientId;
                        options.ClientSecret = googleSecret;
                    });
                }

                if (!string.IsNullOrEmpty(microsoftClientId) && !string.IsNullOrEmpty(microsoftSecret))
                {
                    auth.AddMicrosoft(options =>
                    {
                        options.ClientId = microsoftClientId;
                        options.ClientSecret = microsoftSecret;
                    });
                }
            });

            builder.Services.AddAuthorization(options =>
            {
                options.FallbackPolicy = new Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
            });

            builder.Services.AddRazorPages()
                .AddTipsyBaboonIdentityPages();
            
            builder.Services.AddControllers();

            // CSRF Protection: Configure antiforgery with secure cookie settings
            builder.Services.AddAntiforgery(options =>
            {
                options.HeaderName = "X-XSRF-TOKEN";
                options.Cookie.Name = "XSRF-TOKEN";
                options.Cookie.HttpOnly = true;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                options.Cookie.SameSite = SameSiteMode.Strict;
            });

            builder.Services.AddDistributedMemoryCache();
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromHours(2);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });

            // Intentional registration: keep configuration services for the website itself.
            // `IConfigurationService` and `AppConfigurationManager` are retained so the host
            // can access and manage database-backed configuration even if not actively used
            // yet. This preserves forward compatibility as site-level configuration work
            // progresses.
            builder.Services.AddSingleton<IConfigurationService, ConfigurationService>();
            
            // Identity-backed authentication service (uses UserManager/SignInManager)
            builder.Services.AddScoped<IAuthenticationService, IdentityAuthenticationService>();
            builder.Services.AddScoped<TipsyBaboon.Core.Interfaces.IAuthenticationService>(sp => sp.GetRequiredService<IAuthenticationService>());
            builder.Services.AddScoped<AppConfigurationManager>();
            

            var app = builder.Build();

            TipsyBaboon.Core.Services.ServiceLocator.SetProvider(app.Services);

            if (app.Environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            // Handle status code pages (403, 404, etc.)
            app.UseStatusCodePagesWithReExecute("/Error/{0}");

            app.UseHttpsRedirection();

            app.UseStaticFiles();

            app.UseTipsyBaboonEmbeddedResources();

            app.UseRouting();

            app.UseSession();
            app.UseAuthentication();
            app.UseStaleAuthenticationCheck();
            app.UseImpersonationKeepalive();
            app.UseAuthorization();
            
            // Shorthand path-rewrite middleware removed.
            // Routing is handled by TipsyBaboonUI, Razor Pages, Web API controllers, and static files.
            
            
            
            app.MapRazorPages()
               .WithStaticAssets();
            
            app.MapControllers();

            await app.RunAsync();
        }
    }
}
