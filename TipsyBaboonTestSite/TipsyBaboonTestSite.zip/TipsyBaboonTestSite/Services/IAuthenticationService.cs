// IAuthenticationService has been moved to TipsyBaboon.Core.Interfaces
// This file is kept for backwards compatibility during transition

namespace TipsyBaboonTestSite.Services
{
    // Re-export the Core interface for existing code
    public interface IAuthenticationService : TipsyBaboon.Core.Interfaces.IAuthenticationService
    {
    }
}
