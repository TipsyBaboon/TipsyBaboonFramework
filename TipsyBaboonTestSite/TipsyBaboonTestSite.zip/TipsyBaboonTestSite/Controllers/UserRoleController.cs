using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TipsyBaboon.Core.Data;
using TipsyBaboon.Core.Models;
using TipsyBaboon.Core.Models.Governance;
using TipsyBaboon.Core.FrameworkBase;

namespace TipsyBaboonTestSite.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserRoleController : ControllerBase
    {
        private readonly BaseModelStore _store;

        public UserRoleController(
            BaseModelStore store)
        {
            _store = store;
        }

        [HttpGet("assignments/{userId}")]
        public async Task<IActionResult> GetAssignmentsByUser(Guid userId)
        {
            try
            {
                var allUserRoles = await _store.QueryTypedAsync<UserRole>(new PagedRequest { PageSize = 10000 });
                var userAssignments = allUserRoles.Items
                    .Where(ur => ur.UserId == userId)
                    .Select(ur => new { roleId = ur.RoleId })
                    .ToList();

                return Ok(new { assignments = userAssignments });
            }
            catch (Exception)
            {
                return StatusCode(500, new { error = "Failed to get role assignments" });
            }
        }

        [HttpGet("assignments/role/{roleId}")]
        public async Task<IActionResult> GetAssignmentsByRole(Guid roleId)
        {
            try
            {
                var allUserRoles = await _store.QueryTypedAsync<UserRole>(new PagedRequest { PageSize = 10000 });
                var roleAssignments = allUserRoles.Items
                    .Where(ur => ur.RoleId == roleId)
                    .Select(ur => new { userId = ur.UserId })
                    .ToList();

                return Ok(new { assignments = roleAssignments });
            }
            catch (Exception)
            {
                return StatusCode(500, new { error = "Failed to get user assignments" });
            }
        }

        [HttpPost("assign")]
        public async Task<IActionResult> Assign([FromBody] UserRoleAssignmentRequest request)
        {
            if (request.UserId == Guid.Empty || request.RoleId == Guid.Empty)
            {
                return BadRequest(new { error = "UserId and RoleId are required" });
            }

            try
            {
                var existing = await _store.QueryTypedAsync<UserRole>(new PagedRequest { PageSize = 10000 });
                var existingAssignment = existing.Items
                    .FirstOrDefault(ur => ur.UserId == request.UserId && ur.RoleId == request.RoleId);

                if (existingAssignment != null)
                {
                    return Ok(new { success = true, message = "Role already assigned" });
                }

                var userRole = new UserRole
                {
                    UserId = request.UserId,
                    RoleId = request.RoleId
                };

                await _store.InsertTypedAsync<UserRole>(userRole);

                return Ok(new { success = true, userId = userRole.UserId, roleId = userRole.RoleId });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to assign role" });
            }
        }

        [HttpPost("unassign")]
        public async Task<IActionResult> Unassign([FromBody] UserRoleAssignmentRequest request)
        {
            if (request.UserId == Guid.Empty || request.RoleId == Guid.Empty)
            {
                return BadRequest(new { error = "UserId and RoleId are required" });
            }

            try
            {
                var existing = await _store.QueryTypedAsync<UserRole>(new PagedRequest { PageSize = 10000 });
                var existingAssignment = existing.Items
                    .FirstOrDefault(ur => ur.UserId == request.UserId && ur.RoleId == request.RoleId);

                if (existingAssignment == null)
                {
                    return Ok(new { success = true, message = "Role not assigned" });
                }

                // BasicRights and Anonymous are implicit roles - not stored as UserRole records

                if (request.RoleId == Role.UserAdminRoleId)
                {
                    var allUserRoles = await _store.QueryTypedAsync<UserRole>(new PagedRequest { PageSize = 10000 });
                    var userAdminCount = allUserRoles.Items.Count(ur => ur.RoleId == Role.UserAdminRoleId);
                    
                    if (userAdminCount <= 1)
                    {
                        return BadRequest(new { error = "Cannot remove the last User Admin. The system must have at least one User Admin." });
                    }
                }

                await _store.DeleteTypedAsync<UserRole>(new Dictionary<string, object> { ["UserId"] = existingAssignment.UserId, ["RoleId"] = existingAssignment.RoleId });

                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Failed to unassign role" });
            }
        }
    }

    public class UserRoleAssignmentRequest
    {
        public Guid UserId { get; set; }
        public Guid RoleId { get; set; }
    }
}
